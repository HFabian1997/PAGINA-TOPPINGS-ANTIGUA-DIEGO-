import React from 'react';
import './App.css';
import '@fontsource/poppins/300.css';
import '@fontsource/poppins/400.css';
import '@fontsource/poppins/500.css';
import '@fontsource/poppins/600.css';
import '@fontsource/poppins/700.css';
import '@fontsource/poppins/800.css';
import {Grid} from "@mui/material";
import Pagina from "./Pagina/Pagina";
import RouteLoadingWrapper from "./Pagina/Secciones/Componentes/RouteLoadingWrapper";


function App() {
    return (
        <RouteLoadingWrapper>
            <Grid
                container
                justifyContent={'flex-start'}
                alignItems={'flex-start'}
                size={{xs: 12, sm: 12, md: 12}}>
                <Pagina/>
            </Grid>
        </RouteLoadingWrapper>
    );
}

export default App;

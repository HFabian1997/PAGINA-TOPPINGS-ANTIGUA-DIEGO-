import { Container, Grid, Typography, Box, IconButton, ButtonBase, Button } from "@mui/material";
import { Link } from "react-router-dom";
import logo from "../Recursos/logo_footer.svg";
import FacebookRoundedIcon from '@mui/icons-material/FacebookRounded';
import InstagramIcon from '@mui/icons-material/Instagram';
import YouTubeIcon from '@mui/icons-material/YouTube';

const Footer = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>

            {/* Contenido del footer */}
            <Grid
                container
                justifyContent="center"
                alignItems="center"
                size={{xs: 12, sm: 12, md: 12}}
                sx={{ pt:5, pb: 5, borderTop: '1px solid #ccc' }}>

                <Grid
                    container
                    justifyContent="center"
                    alignItems="center"
                    size={{xs: 12, sm: 12, md: 10}}
                    sx={{maxWidth: '1400px', px:3}}>

                    {/* LOGO */}
                    <Grid container justifyContent="center" alignItems="center" size={{xs: 12}}>
                        <img src={logo} alt="Toppings Logo" style={{ width: 100, height: 100 }}/>
                    </Grid>

                    {/* Horarios */}
                    {/* ...Tu código de horarios aquí... */}

                    {/* Redes sociales */}
                    <Grid container justifyContent="center" size={{xs: 12}} sx={{pt:3}}>
                        <Box
                            component="ul"
                            sx={{
                                display: "flex",
                                gap: 4,
                                listStyle: "none",
                                p: 0,
                                m: 0
                            }}
                        >
                            <li>
                                <ButtonBase
                                    component="a"
                                    href="https://www.instagram.com/marthaalvarez.arq"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <InstagramIcon sx={{ fontSize: 62, color: 'Black' }}/>
                                </ButtonBase>
                            </li>
                            <li>
                                <ButtonBase
                                    component="a"
                                    href="https://youtube.com/@arq.marthaalvarez"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <FacebookRoundedIcon sx={{ fontSize: 62, color: 'Black' }}/>
                                </ButtonBase>
                            </li>
                            <li>
                                <ButtonBase
                                    component="a"
                                    href="https://co.linkedin.com/in/hern%C3%A1n-dar%C3%ADo-jojoa-rangel-88560489"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <YouTubeIcon sx={{ fontSize: 62, color: 'Black' }}/>
                                </ButtonBase>
                            </li>
                        </Box>

                        {/* Botón Admin */}
                        <Grid container size={{xs: 12, sm: 12, md: 12}} justifyContent="center" sx={{pt:3}}>
                            <ButtonBase
                                component={Link}
                                to="/dashboard"
                                sx={{ borderRadius: "20px", px: 3 }}
                            >
                                Admin
                            </ButtonBase>
                        </Grid>

                        {/* Derechos reservados */}
                        <Grid container justifyContent="center" alignItems="center" size={{xs: 12}} sx={{pt:3}}>
                            <Typography sx={{color: 'black'}}>
                                Todos los derechos reservados -
                            </Typography>
                        </Grid>
                        <Grid container justifyContent="center" alignItems="center" size={{xs: 12}}>
                            <Typography sx={{color: 'black'}}>
                                toppings.com.co ©
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    )
}
export default Footer;

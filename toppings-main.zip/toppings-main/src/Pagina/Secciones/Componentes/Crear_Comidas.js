import {Grid} from "@mui/material";
import Lista_Comidas_Dashboard from "./Lista_Comidas_Dashboard";
import Boton_Crear_Comidas from "./SubComponentes/Boton_Crear_Comidas";

const Crear_Comidas = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Boton_Crear_Comidas/>
            </Grid>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Lista_Comidas_Dashboard/>
            </Grid>
        </Grid>
    )
}
export default Crear_Comidas;


import {
    Grid,
    TextField,
    MenuItem,
    Button,
    CircularProgress,
    Typography,
    Snackbar,
    Alert
} from "@mui/material";
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { db, storage } from "../../../firebase/firebase";
import { doc, getDoc, updateDoc, Timestamp } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

const categorias = [
    "Conos soft",
    "Malteadas",
    "Malteadas (Sabores)",
    "Sundae tornado",
    "Sundae tornado (Toppings)",
    "Fruty soft",
    "Fruty soft (Base)",
    "Fruty soft (Toppings)",
    "Fruty soft (Frutas)",
    "Fruty soft (Salsas)",
    "Durazno con crema",
    "Durazno con crema (Toppings)",
    "Ensalada de frutas",
    "Jugos naturales",
    "Jugos naturales (Frutas)",
    "Obleas"
];

const Editar_Helados_Dashboard = () => {
    const { id } = useParams();

    const [categoria, setCategoria] = useState('');
    const [titulo, setTitulo] = useState('');
    const [descripcion, setDescripcion] = useState('');
    const [precio1, setPrecio1] = useState('');
    const [precio2, setPrecio2] = useState('');
    const [imagen, setImagen] = useState(null);
    const [existingImageUrl, setExistingImageUrl] = useState('');
    const [loading, setLoading] = useState(false);
    const [snackbarOpen, setSnackbarOpen] = useState(false);

    // Detectar si es subcategoría
    const esSubcategoria = categoria.includes("(");

    useEffect(() => {
        const fetchHelado = async () => {
            try {
                const docRef = doc(db, "helados", id); // ✅ usar la misma colección
                const docSnap = await getDoc(docRef);
                if (docSnap.exists()) {
                    const data = docSnap.data();
                    setCategoria(data.categoria || '');
                    setTitulo(data.titulo || '');
                    setDescripcion(data.descripcion || '');
                    setPrecio1(data.precio1 || '');
                    setPrecio2(data.precio2 || '');
                    setExistingImageUrl(data.imagen || '');
                }
            } catch (error) {
                console.error("Error al cargar el helado:", error);
            }
        };

        fetchHelado();
    }, [id]);

    const handleImageChange = (e) => {
        if (e.target.files[0]) {
            setImagen(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Validaciones según tipo
        if (esSubcategoria) {
            if (!categoria || !titulo.trim() || (!imagen && !existingImageUrl)) {
                alert("Debe ingresar al menos nombre e imagen.");
                return;
            }
        } else {
            if (!categoria || !titulo.trim() || !precio1.trim() || (!imagen && !existingImageUrl)) {
                alert("Todos los campos son obligatorios, incluyendo la imagen.");
                return;
            }
        }

        setLoading(true);
        try {
            let imageUrl = existingImageUrl;

            if (imagen) {
                const folder = "helados"; // ✅ misma carpeta
                const imageRef = ref(storage, `${folder}/${Date.now()}_${imagen.name}`);
                await uploadBytes(imageRef, imagen);
                imageUrl = await getDownloadURL(imageRef);
            }

            await updateDoc(doc(db, "helados", id), {
                categoria,
                titulo,
                ...(esSubcategoria ? {} : { descripcion, precio1, precio2 }),
                imagen: imageUrl,
                updatedAt: Timestamp.now()
            });

            setSnackbarOpen(true);
        } catch (error) {
            console.error("Error al actualizar el helado:", error);
            alert("Error al actualizar el helado");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Grid container justifyContent="flex-start" alignItems="flex-start">
            <Grid
                container justifyContent="flex-start" alignItems="flex-start"
                component="form"
                onSubmit={handleSubmit}
                sx={{ maxWidth: 500, px: 3, pt: 5 }}
            >
                {/* Dropdown de Categorías */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }} sx={{ mb: 2 }}>
                    <TextField
                        select
                        label="Categoría"
                        fullWidth
                        value={categoria}
                        onChange={(e) => setCategoria(e.target.value)}
                    >
                        {categorias.map((cat) => (
                            <MenuItem key={cat} value={cat}>
                                {cat}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>

                {/* Título */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                    <TextField
                        label="Nombre del Helado"
                        fullWidth
                        margin="normal"
                        value={titulo}
                        onChange={(e) => setTitulo(e.target.value)}
                    />
                </Grid>

                {/* Solo si no es subcategoría */}
                {!esSubcategoria && (
                    <>
                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Ingredientes"
                                fullWidth
                                multiline
                                rows={3}
                                margin="normal"
                                value={descripcion}
                                onChange={(e) => setDescripcion(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Valor 1"
                                fullWidth
                                margin="normal"
                                value={precio1}
                                onChange={(e) => setPrecio1(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Valor 2"
                                fullWidth
                                margin="normal"
                                value={precio2}
                                onChange={(e) => setPrecio2(e.target.value)}
                            />
                        </Grid>
                    </>
                )}

                {/* Imagen */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                    <Button component="label" variant="outlined" fullWidth sx={{ mt: 2 }}>
                        {existingImageUrl ? "Cambiar Imagen" : "Subir Imagen"}
                        <input type="file" hidden accept="image/*" onChange={handleImageChange} />
                    </Button>
                    {imagen && (
                        <Typography variant="body2" sx={{ mt: 1 }}>
                            {imagen.name}
                        </Typography>
                    )}
                    {!imagen && existingImageUrl && (
                        <Typography variant="body2" sx={{ mt: 1 }}>
                            Imagen actual: {existingImageUrl.split("/").pop()}
                        </Typography>
                    )}
                </Grid>

                {/* Botón */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                    <Button type="submit" variant="contained" fullWidth sx={{ mt: 3 }} disabled={loading}>
                        {loading ? <CircularProgress size={24} /> : "Actualizar Helado"}
                    </Button>
                </Grid>
            </Grid>

            {/* Snackbar */}
            <Snackbar
                open={snackbarOpen}
                autoHideDuration={3000}
                onClose={() => setSnackbarOpen(false)}
                anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
            >
                <Alert onClose={() => setSnackbarOpen(false)} severity="success" sx={{ width: "100%" }}>
                    Helado actualizado correctamente ✅
                </Alert>
            </Snackbar>
        </Grid>
    );
};

export default Editar_Helados_Dashboard;

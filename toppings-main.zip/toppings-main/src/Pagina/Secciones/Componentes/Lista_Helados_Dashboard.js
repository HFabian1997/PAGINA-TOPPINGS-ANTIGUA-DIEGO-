import { Button, Grid, Typography, Snackbar, Alert } from "@mui/material";
import { useResponsive } from "../../../Modulo_Responsive/Hooks/useResponsive";
import { useEffect, useState } from "react";
import { collection, deleteDoc, doc, onSnapshot } from "firebase/firestore";
import { db } from "../../../firebase/firebase";

const Lista_Helados_Dashboard = () => {
    const { sCell } = useResponsive();
    const [productos, setProductos] = useState([]);
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [mensajeExito, setMensajeExito] = useState('');

    const handleEliminar = async (id, titulo) => {
        const confirmar = window.confirm(`¿Estás seguro de que deseas eliminar el producto "${titulo}"?`);
        if (!confirmar) return;

        try {
            await deleteDoc(doc(db, "helados", id));
            setMensajeExito(`Producto "${titulo}" eliminado con éxito.`);
            setOpenSnackbar(true);
        } catch (error) {
            console.error("Error al eliminar el producto:", error);
        }
    };

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, "helados"), (querySnapshot) => {
            const docs = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            setProductos(docs);
        });

        return () => unsubscribe();
    }, []);

    if (productos.length === 0) return <Typography sx={{ pl: 13.5 }}>Cargando productos...</Typography>;

    const categorias = {};
    productos.forEach(prod => {
        const categoriaCompleta = prod.categoria;
        if (!categorias[categoriaCompleta]) {
            categorias[categoriaCompleta] = [];
        }
        categorias[categoriaCompleta].push(prod);
    });

    const ordenCategorias = [
        "Conos soft",
        "Malteadas",
        "Sundae tornado",
        "Fruty soft",
        "Obleas",
        "Durazno con crema",
        "Ensalada de frutas",
        "Jugos naturales"
    ];

    const categoriasOrdenadas = Object.keys(categorias).sort((a, b) => {
        const baseA = a.split(" (")[0];
        const baseB = b.split(" (")[0];
        const indexA = ordenCategorias.indexOf(baseA);
        const indexB = ordenCategorias.indexOf(baseB);
        return indexA - indexB;
    });

    return (
        <Grid
            container
            justifyContent={"center"}
            alignItems={"center"}
            size={{ xs: 12, sm: 12, md: 10 }}
            sx={{ pt: 10 }}
        >
            <Grid container size={{ xs: 12, sm: 12, md: 12 }} sx={{ maxWidth: 1400, px: 3 }}>
                <Grid container justifyContent={"flex-start"} alignItems={"flex-start"} size={{ xs: 12, sm: 12, md: 12 }}>
                    {categoriasOrdenadas.map(cat => (
                        categorias[cat] && categorias[cat].length > 0 && (
                            <Grid key={cat} container size={{ xs: 12, sm: 12, md: 12 }} sx={{ mb: 3 }}>
                                {/* 👇 ID agregado al título */}
                                <Typography
                                    id={cat.replace(/\s+/g, '-')}
                                    sx={{ mb: 1, fontSize: 26, fontWeight: 600 }}
                                >
                                    {cat}
                                </Typography>

                                {categorias[cat].map(item => (
                                    <Grid
                                        container
                                        justifyContent={"flex-start"}
                                        alignItems={"flex-start"}
                                        key={item.id}
                                        size={{ xs: 12, sm: 12, md: 12 }}
                                    >
                                        <Grid
                                            container
                                            spacing={2}
                                            size={{ xs: 12, sm: 12, md: 12 }}
                                            sx={{ borderBottom: "1px solid #ccc", py: 1 }}
                                        >
                                            <Grid container size={{ xs: 12, sm: 12, md: 7 }}>
                                                <Typography>
                                                    {item.titulo}
                                                </Typography>
                                            </Grid>
                                            <Grid
                                                container
                                                justifyContent={"flex-end"}
                                                alignItems={"flex-start"}
                                                size={{ xs: 12, sm: 5, md: 5 }}
                                            >
                                                <Button href={`/dashboard/helados/${item.id}`}>Editar</Button>
                                                <Button onClick={() => handleEliminar(item.id, item.titulo)}>Eliminar</Button>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                ))}
                            </Grid>
                        )
                    ))}
                </Grid>
            </Grid>

            <Snackbar
                open={openSnackbar}
                autoHideDuration={3000}
                onClose={() => setOpenSnackbar(false)}
                anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
            >
                <Alert onClose={() => setOpenSnackbar(false)} severity="success" sx={{ width: "100%" }}>
                    {mensajeExito}
                </Alert>
            </Snackbar>
        </Grid>
    );
};

export default Lista_Helados_Dashboard;

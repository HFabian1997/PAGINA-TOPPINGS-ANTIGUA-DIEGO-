import {Grid, Typography,} from "@mui/material";

const Pagina_Misteriosa = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}
            sx={{background: '#FFEAB5', mt:3}}>
            <Grid
                container
                justifyContent={'center'}
                alignItems={'center'}
                size={{xs: 12, sm: 12, md: 10}}
                sx={{maxWidth: '1400px', px:3, py:15}}>
                <Grid
                    container
                    justifyContent={'center'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Grid
                        contianer
                        justifyContent={'flex-start'}
                        alignItems={'center'}
                        size={{xs: 12, sm: 12, md: 6}}>
                        <Typography sx={{
                            fontSize: 48,
                            fontWeight: 600,
                            textAlign: "left",
                            color: "black",
                        }}>
                            Página misteriosa
                        </Typography>
                        <Typography sx={{
                            fontSize: 16,
                            fontWeight: 300,
                            textAlign: "flex-start",
                            color: "black",
                            pt: 2,
                            maxWidth: "450px"
                        }}>
                            Espacio creado para hacer promociones, retos, actividades, productos de temporada
                        </Typography>
                    </Grid>
                    <Grid
                        contianer
                        justifyContent={'center'}
                        alignItems={'center'}
                        size={{xs: 12, sm: 12, md: 6}}>
                        <Typography sx={{
                            fontSize: 32,
                            fontWeight: 400,
                            textAlign: "center",
                            color: "black",
                            pt: 4,
                        }}>
                            misterio
                        </Typography>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    );
};

export default Pagina_Misteriosa;

import { useState } from 'react';
import { TextField, MenuItem, Button, CircularProgress, Typography, Grid } from '@mui/material';
import { collection, addDoc, Timestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../../firebase/firebase';

const Formulario_Crear_Comidas = () => {
    const [categoria, setCategoria] = useState('');
    const [titulo, setTitulo] = useState('');
    const [descripcion, setDescripcion] = useState('');
    const [precio1, setPrecio1] = useState('');
    const [precio2, setPrecio2] = useState('');
    const [imagen, setImagen] = useState(null);
    const [loading, setLoading] = useState(false);

    // Definimos las secciones
    const secciones = {
        Salchipapas: [
            'Una salchi o miedo?',
            'Somos las salchis más chimbas',
            'Para todo el parche'
        ],
        Hamburguesas: ['Hamburguesas'],
        Perros: ['Te gustan perro o perras?'],
        Sándwich: [
            'Sandwiches para una persona',
            'Sandwiches para dos personas'
        ],
        Mazorcada: ['Mazorcadas'],
        Otros: ['Otros'],
        Bebidas: ['Bebidas'],
        Topping: ['Salchipapas', 'Hamburguesas'] // 👈 aquí los toppings con subcategorías
    };

    // Formateamos las categorías con paréntesis solo si tienen más de 1 título
    const categoriasConFormato = Object.entries(secciones).flatMap(([cat, subs]) =>
        subs.length > 1
            ? subs.map((sub) => `${cat} (${sub})`)
            : [cat]
    );

    const handleImageChange = (e) => {
        if (e.target.files && e.target.files.length > 0) {
            setImagen(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Validaciones dinámicas según categoría
        if (categoria.includes("Bebidas")) {
            if (!titulo.trim() || !precio1.trim()) {
                alert('Los campos de bebida son obligatorios.');
                return;
            }
        } else if (categoria.includes("Topping")) {
            if (!titulo.trim() || !descripcion.trim() || !precio1.trim() || !imagen) {
                alert('Los campos de topping son obligatorios.');
                return;
            }
        } else {
            if (!categoria || !titulo.trim() || !descripcion.trim() || !precio1.trim() || !imagen) {
                alert('Todos los campos son obligatorios, incluyendo la imagen.');
                return;
            }
        }

        setLoading(true);
        try {
            let imageUrl = null;

            if (!categoria.includes("Bebidas") && imagen) {
                const folder = categoria.split(" ")[0].toLowerCase().replace(/ /g, '_');
                const imageRef = ref(storage, `${folder}/${Date.now()}_${imagen.name}`);
                await uploadBytes(imageRef, imagen);
                imageUrl = await getDownloadURL(imageRef);
            }

            await addDoc(collection(db, 'productos'), {
                categoria,
                titulo,
                descripcion,
                precio1,
                precio2,
                imagen: imageUrl,
                createdAt: Timestamp.now(),
            });

            alert('Producto creado con éxito ✅');

            setCategoria('');
            setTitulo('');
            setDescripcion('');
            setPrecio1('');
            setPrecio2('');
            setImagen(null);
        } catch (error) {
            console.error('❌ Error al crear producto:', error);
            alert('Error al crear producto');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Grid container justifyContent="flex-start" alignItems="flex-start">
            <Grid
                container justifyContent="flex-start" alignItems="flex-start"
                component="form"
                onSubmit={handleSubmit}
                sx={{ maxWidth: 500, px: 3, pt: 5 }}
            >
                {/* Categoría */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }} sx={{ mb: 2 }}>
                    <TextField
                        select
                        label="Categoría"
                        fullWidth
                        value={categoria}
                        onChange={(e) => setCategoria(e.target.value)}
                    >
                        {categoriasConFormato.map((cat) => (
                            <MenuItem key={cat} value={cat}>
                                {cat}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>

                {/* Si es Bebida */}
                {categoria.includes("Bebidas") && (
                    <>
                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Nombre de la Bebida"
                                fullWidth
                                margin="normal"
                                value={titulo}
                                onChange={(e) => setTitulo(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Precio"
                                fullWidth
                                margin="normal"
                                value={precio1}
                                onChange={(e) => setPrecio1(e.target.value)}
                            />
                        </Grid>
                    </>
                )}

                {/* Si es Topping */}
                {categoria.includes("Topping") && (
                    <>
                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Título "
                                fullWidth
                                margin="normal"
                                value={titulo}
                                onChange={(e) => setTitulo(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Descripción"
                                fullWidth
                                multiline
                                rows={3}
                                margin="normal"
                                value={descripcion}
                                onChange={(e) => setDescripcion(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Precio"
                                fullWidth
                                margin="normal"
                                value={precio1}
                                onChange={(e) => setPrecio1(e.target.value)}
                            />
                        </Grid>
                    </>
                )}

                {/* Si NO es Bebida ni Topping → formulario completo */}
                {!categoria.includes("Bebidas") && !categoria.includes("Topping") && (
                    <>
                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Nombre del Plato"
                                fullWidth
                                margin="normal"
                                value={titulo}
                                onChange={(e) => setTitulo(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Ingredientes"
                                fullWidth
                                multiline
                                rows={3}
                                margin="normal"
                                value={descripcion}
                                onChange={(e) => setDescripcion(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Valor 1"
                                fullWidth
                                margin="normal"
                                value={precio1}
                                onChange={(e) => setPrecio1(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Valor 2"
                                fullWidth
                                margin="normal"
                                value={precio2}
                                onChange={(e) => setPrecio2(e.target.value)}
                            />
                        </Grid>
                    </>
                )}

                {/* Imagen (no aparece en Bebidas) */}
                {!categoria.includes("Bebidas") && (
                    <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                        <Button component="label" variant="outlined" fullWidth sx={{ mt: 2 }}>
                            Subir Imagen
                            <input type="file" hidden accept="image/*" onChange={handleImageChange} />
                        </Button>
                        {imagen && (
                            <Typography variant="body2" sx={{ mt: 1 }}>
                                {imagen.name}
                            </Typography>
                        )}
                    </Grid>
                )}

                {/* Botón enviar */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                    <Button type="submit" variant="contained" fullWidth sx={{ mt: 3 }} disabled={loading}>
                        {loading ? <CircularProgress size={24} /> : 'Publicar Producto'}
                    </Button>
                </Grid>
            </Grid>
        </Grid>
    );
};

export default Formulario_Crear_Comidas;

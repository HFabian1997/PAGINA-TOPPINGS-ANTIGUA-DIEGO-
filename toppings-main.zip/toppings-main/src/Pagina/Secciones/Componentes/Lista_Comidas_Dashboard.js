import { Button, Grid, Typography, Snackbar, Alert } from "@mui/material";
import { useResponsive } from "../../../Modulo_Responsive/Hooks/useResponsive";
import { useEffect, useState } from "react";
import { collection, deleteDoc, doc, onSnapshot } from "firebase/firestore";
import { db } from "../../../firebase/firebase";

const Lista_Comidas_Dashboard = () => {
    const { sCell } = useResponsive();
    const [productos, setProductos] = useState([]);
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [mensajeExito, setMensajeExito] = useState('');

    const handleEliminar = async (id, titulo) => {
        const confirmar = window.confirm(`¿Estás seguro de que deseas eliminar el producto "${titulo}"?`);
        if (!confirmar) return;

        try {
            await deleteDoc(doc(db, "productos", id));
            setMensajeExito(`Producto "${titulo}" eliminado con éxito.`);
            setOpenSnackbar(true);
        } catch (error) {
            console.error("Error al eliminar el producto:", error);
        }
    };

    useEffect(() => {
        // 🔥 Suscripción en tiempo real
        const unsubscribe = onSnapshot(collection(db, 'productos'), (querySnapshot) => {
            const docs = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            setProductos(docs);
        });

        return () => unsubscribe(); // limpiar suscripción
    }, []);

    if (productos.length === 0) return <Typography sx={{ pl: 13.5 }}>Cargando productos...</Typography>;

    const categorias = {};
    productos.forEach(prod => {
        const categoriaBase = prod.categoria.split(" (")[0];
        if (!categorias[categoriaBase]) {
            categorias[categoriaBase] = [];
        }
        categorias[categoriaBase].push(prod);
    });

    // 👇 Orden de agrupación (las CLAVES que ya existen en Firestore)
    const ordenCategorias = [
        'Salchipapas',
        'Hamburguesas',
        'Perros',
        'Sándwich',
        'Mazorcada',
        'Otros',
        'Bebidas',
        'Topping'
    ];

    // 👇 Título visible + ID SEGURO para scroll
    const tituloConfig = {
        'Salchipapas': { id: 'una-salchi-o-miedo', titulo: 'Una salchi o miedo?' },
        'Hamburguesas': { id: 'hamburguesas', titulo: 'Hamburguesas' },
        'Perros': { id: 'te-gustan-perro-o-perras', titulo: 'Te gustan perro o perras?' },
        'Sándwich': { id: 'sandwiches-para-una-persona', titulo: 'Sandwiches para una persona' },
        'Mazorcada': { id: 'mazorcadas', titulo: 'Mazorcadas' },
        'Otros': { id: 'otros', titulo: 'Otros' },
        'Bebidas': { id: 'bebidas', titulo: 'Bebidas' },
        'Topping': { id: 'topping', titulo: 'Topping' }
    };

    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{ xs: 12, sm: 12, md: 10 }} sx={{ pt: 10 }}
        >
            <Grid container size={{ xs: 12, sm: 12, md: 12 }} sx={{ maxWidth: 1400, px: 3 }}>
                <Grid container justifyContent={'flex-start'} alignItems={'flex-start'} size={{ xs: 12, sm: 12, md: 12 }}>
                    {ordenCategorias.map(cat => (
                        categorias[cat] && categorias[cat].length > 0 && (
                            <Grid key={cat} container size={{ xs: 12, sm: 12, md: 12 }} sx={{ mb: 3 }}>
                                {/* 🔹 Título con id seguro */}
                                <Typography
                                    id={tituloConfig[cat].id}
                                    sx={{ mb: 1, fontSize: 26, fontWeight: 600 }}
                                >
                                    {tituloConfig[cat].titulo}
                                </Typography>

                                {categorias[cat].map(item => (
                                    <Grid
                                        container
                                        justifyContent={'flex-start'}
                                        alignItems={'flex-start'}
                                        key={item.id}
                                        size={{ xs: 12, sm: 12, md: 12 }}
                                    >
                                        <Grid container spacing={2} size={{ xs: 12, sm: 12, md: 12 }}
                                              sx={{ borderBottom: '1px solid #ccc', py: 1 }}>
                                            <Grid container size={{ xs: 12, sm: 12, md: 7 }}>
                                                <Typography>
                                                    {cat === "Topping"
                                                        ? item.descripcion  // 👈 mostrar descripción en vez del título
                                                        : item.titulo}
                                                    {item.categoria.includes("(") && (
                                                        <Typography component="span" sx={{ fontSize: 14, color: "gray", ml: 1 }}>
                                                            ({item.categoria.split("(")[1].replace(")", "")})
                                                        </Typography>
                                                    )}
                                                </Typography>
                                            </Grid>
                                            <Grid container justifyContent={'flex-end'} alignItems={'flex-start'} size={{ xs: 12, sm: 5, md: 5 }}>
                                                <Button href={`/dashboard/menu/${item.id}`}>Editar</Button>
                                                <Button onClick={() => handleEliminar(item.id, item.titulo)}>Eliminar</Button>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                ))}
                            </Grid>
                        )
                    ))}
                </Grid>
            </Grid>

            <Snackbar
                open={openSnackbar}
                autoHideDuration={3000}
                onClose={() => setOpenSnackbar(false)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
            >
                <Alert onClose={() => setOpenSnackbar(false)} severity="success" sx={{ width: '100%' }}>
                    {mensajeExito}
                </Alert>
            </Snackbar>
        </Grid>
    );
};

export default Lista_Comidas_Dashboard;

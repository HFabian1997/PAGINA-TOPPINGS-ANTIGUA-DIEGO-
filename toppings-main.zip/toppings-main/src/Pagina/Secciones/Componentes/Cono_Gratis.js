import {Grid, Typography, Button, ButtonBase} from "@mui/material";
import { useState } from "react";
import uploadImg from "../../../Recursos/subir.svg"; //
const Pagina_Misteriosa = () => {
    const [imagen, setImagen] = useState(null);

    const manejarSeleccion = (e) => {
        const archivo = e.target.files[0];
        if (archivo) {
            setImagen(URL.createObjectURL(archivo)); // Vista previa
        }
    };

    const manejarEnviar = () => {
        setImagen(null); // Resetear y volver al estado inicial
    };

    return (
        <Grid
            container
            justifyContent={"center"}
            alignItems={"center"}
            size={{ xs: 12, sm: 12, md: 12 }}
        >
            <Grid
                container
                justifyContent={"center"}
                alignItems={"center"}
                size={{ xs: 12, sm: 12, md: 10 }}
                sx={{ maxWidth: "1400px", px: 3, pt: 15 }}
            >
                <Grid
                    container
                    justifyContent={"center"}
                    alignItems={"center"}
                    size={{ xs: 12, sm: 12, md: 12 }}
                >
                    {/* Texto izquierda */}
                    <Grid
                        container
                        justifyContent={"flex-start"}
                        alignItems={"center"}
                        size={{ xs: 12, sm: 12, md: 6 }}
                    >
                        <Typography
                            sx={{
                                fontSize: 48,
                                fontWeight: 600,
                                textAlign: "left",
                                color: "black",
                            }}
                        >
                            ¿Cómo ganar un
                        </Typography>
                        <Typography
                            sx={{
                                fontSize: 48,
                                fontWeight: 600,
                                textAlign: "left",
                                color: "black",
                            }}
                        >
                            cono gratis?
                        </Typography>
                        <Typography
                            sx={{
                                fontSize: 16,
                                fontWeight: 300,
                                textAlign: "left",
                                color: "black",
                                pt: 2,
                                maxWidth: "450px",
                            }}
                        >
                            Sube una historia en toppings en cualquier red social y
                            compártenos un pantallazo
                        </Typography>
                    </Grid>

                    {/* Subir imagen derecha */}
                    <Grid
                        container
                        justifyContent={"center"}
                        alignItems={"center"}
                        size={{ xs: 12, sm: 12, md: 6 }}
                        sx={{ pt: 4 }}
                    >
                        <Grid
                            container
                            justifyContent={"center"}
                            alignItems={"center"}
                            sx={{
                                backgroundColor: "#FFA500", // amarillo
                                borderRadius: "32px",
                                width: "100%",
                                maxWidth: "400px",
                                minHeight: "350px",
                                p: 3
                            }}
                        >
                            {!imagen ? (
                                <>
                                    {/* Imagen en lugar de los íconos */}
                                    <Grid
                                        container
                                        justifyContent={"center"}
                                        alignItems={"center"}
                                        size={{ xs: 12, sm: 12, md: 12 }}
                                    >
                                        <img
                                            src={uploadImg}
                                            alt="Subir archivo"
                                            style={{ width: "80px", height: "80px" }}
                                        />
                                    </Grid>

                                    {/* Texto */}
                                    <Typography
                                        sx={{
                                            color: "white",
                                            fontSize: 16,
                                            fontWeight: 500,
                                            textAlign: "center",
                                            maxWidth: "250px",
                                        }}
                                    >
                                        Arrastra la captura de pantalla aquí
                                    </Typography>

                                    {/* Botón de seleccionar archivo */}
                                    <ButtonBase
                                        variant="contained"
                                        component="label"
                                        sx={{
                                            backgroundColor: "#CC6F0F",
                                            color: "white",
                                            borderRadius: "20px",
                                            fontWeight: 500,
                                            px: 5,
                                            py:1,
                                            "&:hover": {
                                                backgroundColor: "#CC6F0F",
                                            },
                                        }}
                                    >
                                        Seleccionar del dispositivo
                                        <input
                                            type="file"
                                            hidden
                                            accept="image/*"
                                            onChange={manejarSeleccion}
                                        />
                                    </ButtonBase>
                                </>
                            ) : (
                                <>
                                    {/* Vista previa de la imagen */}
                                    <img
                                        src={imagen}
                                        alt="Vista previa"
                                        style={{
                                            maxWidth: "100%",
                                            borderRadius: "12px",
                                            marginBottom: "16px",
                                        }}
                                    />

                                    {/* Botones Cambiar y Enviar */}
                                    <Grid container justifyContent="center" spacing={6}>
                                        {/* Botón Cambiar */}
                                        <Grid item xs={6}>
                                            <ButtonBase
                                                variant="contained"
                                                component="label"
                                                sx={{
                                                    backgroundColor: "#CC6F0F",
                                                    color: "white",
                                                    borderRadius: "20px",
                                                    px: 3,
                                                    py: 1,
                                                    width: "100%", // ocupa todo el ancho del Grid
                                                    "&:hover": {
                                                        backgroundColor: "#CC6F0F",
                                                    },
                                                }}
                                            >
                                                <Typography
                                                    sx={{
                                                        color: "white",
                                                        fontSize: 16,
                                                        fontWeight: 500,
                                                        textAlign: "center",
                                                    }}
                                                >
                                                    Cambiar
                                                </Typography>
                                                <input
                                                    type="file"
                                                    hidden
                                                    accept="image/*"
                                                    onChange={manejarSeleccion}
                                                />
                                            </ButtonBase>
                                        </Grid>

                                        {/* Botón Enviar */}
                                        <Grid item xs={6}>
                                            <ButtonBase
                                                variant="contained"
                                                onClick={manejarEnviar}
                                                sx={{
                                                    backgroundColor: "#CC6F0F",
                                                    color: "white",
                                                    borderRadius: "20px",
                                                    px: 4,
                                                    py: 1,
                                                    width: "100%", // ocupa todo el ancho del Grid
                                                    "&:hover": {
                                                        backgroundColor: "#CC6F0F",
                                                    },
                                                }}
                                            >
                                                <Typography
                                                    sx={{
                                                        color: "white",
                                                        fontSize: 16,
                                                        fontWeight: 500,
                                                        textAlign: "center",
                                                    }}
                                                >
                                                    Enviar
                                                </Typography>
                                            </ButtonBase>
                                        </Grid>
                                    </Grid>
                                </>
                            )}
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    );
};

export default Pagina_Misteriosa;

import {Grid} from "@mui/material";
import Formulario_Crear_Comidas from "./Formulario_Crear_Comidas";

const Crear_Comidas_Dashboard = () => {

    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'flex-start'}
            size={{xs: 12, sm: 12, md: 12}}>

            <Grid container justifyContent={'center'}
                  alignItems={'flex-start'} size={{xs: 12, sm: 12, md: 10}} sx={{maxWidth: '1400px', px:3}}>
                <Grid container justifyContent={'flex-start'}
                      alignItems={'flex-start'} size={{xs: 12, sm: 12, md: 12}}>
                    <Formulario_Crear_Comidas/>
                </Grid>
            </Grid>

        </Grid>
    )

}
export default Crear_Comidas_Dashboard;
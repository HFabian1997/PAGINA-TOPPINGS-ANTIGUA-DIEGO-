import { Grid, Container, Typography, TextField, Button } from "@mui/material";
import React, { useState } from "react";
import personajes from "../../../Recursos/opiniones.svg";

const Opiniones = () => {
    const [mensaje, setMensaje] = useState("");

    const handleEnviar = () => {
        if (mensaje.trim() === "") {
            alert("Por favor escribe un mensaje antes de enviar");
            return;
        }
        // Aquí podrías enviar el mensaje a tu backend o correo
        alert("Mensaje enviado: " + mensaje);

        // Limpiar campo después de enviar
        setMensaje("");
    };

    return (
        <Container maxWidth="md" sx={{ py: 6 }}>
            <Grid
                container
                direction="column"
                justifyContent="center"
                alignItems="center"
                spacing={3}
            >
                <Grid item xs={12}>
                    <Typography
                        variant="h3"
                        sx={{
                            fontWeight: 700,
                            textAlign: "center",
                        }}
                    >
                        Nos importa mucho lo que piensas
                    </Typography>
                </Grid>

                <Grid item xs={12}>
                    <Typography
                        variant="body1"
                        sx={{
                            fontWeight: 400,
                            textAlign: "center",
                            color: "text.secondary",
                        }}
                    >
                        Te agradecemos una opinión o sugerencia
                    </Typography>
                </Grid>

                <Grid item xs={12} sm={12} md={12}>
                    <TextField
                        fullWidth
                        multiline
                        rows={3}
                        placeholder="Mensaje"
                        variant="outlined"
                        value={mensaje}
                        onChange={(e) => setMensaje(e.target.value)}
                        sx={{ width: "500px", maxWidth: "100%" }}
                    />
                </Grid>

                {/* Botón centrado */}
                <Grid item xs={12} textAlign="center">
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleEnviar}
                        sx={{ mb: 4, borderRadius: 3, px: 4 }}
                    >
                        Enviar
                    </Button>
                </Grid>

                <Grid item xs={12} sm={10} md={8} textAlign="center">
                    <img
                        src={personajes}
                        alt="Personajes Toppings"
                        style={{ maxWidth: "100%", height: "auto" }}
                    />
                </Grid>
            </Grid>
        </Container>
    );
};

export default Opiniones;

import React, { useEffect, useState } from "react";
import { Grid, CircularProgress, Typography } from "@mui/material";
import Tarjeta_menu from "../../Tarjetas/Tarjeta_menu";
import Tarjeta_salchipapa_parche from "../../Tarjetas/Tarjeta_salchipapa_parche";
import Tarjeta_Toppings from "../../Tarjetas/Tarjeta_Toppings";
import Tarjeta_Bebidas from "../../Tarjetas/Tarjeta_Bebidas";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../../../../firebase/firebase";
import { useResponsive } from "../../../../Modulo_Responsive/Hooks/useResponsive";

const ListaMenu = () => {
    const { sCell } = useResponsive();
    const [productos, setProductos] = useState([]);
    const [loading, setLoading] = useState(true);

    const ordenSubcategorias = [
        "Una salchi o miedo?",
        "Somos las salchis más chimbas",
        "Para todo el parche",
        "Toppings Salchipapa",
        "Hamburguesas",
        "Toppings Hamburguesa",
        "Te gustan perro o perras?",
        "Sandwiches para una persona",
        "Sandwiches para dos personas",
        "Mazorcadas",
        "Otros",
        "Bebidas",
    ];

    const extraerSubcategoria = (categoria) => {
        if (categoria.includes("(")) {
            return categoria.split("(")[1].replace(")", "").trim();
        }
        return categoria.trim();
    };

    useEffect(() => {
        const fetchProductos = async () => {
            try {
                const querySnapshot = await getDocs(collection(db, "productos"));
                const data = querySnapshot.docs.map((doc) => ({
                    id: doc.id,
                    ...doc.data(),
                }));
                setProductos(data);
            } catch (error) {
                console.error("❌ Error cargando productos:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchProductos();
    }, []);

    if (loading) {
        return (
            <Grid container justifyContent="center" alignItems="center" sx={{ minHeight: "200px" }}>
                <CircularProgress />
            </Grid>
        );
    }

    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{ xs: 12, sm: 12, md: 12 }}
            sx={{ pt: sCell ? 20 : 15 }}
        >
            {(() => {
                let visibleIndex = 0;
                return ordenSubcategorias.map((subCat) => {
                    let tituloPersonalizado = subCat;
                    if (subCat === "Toppings Salchipapa") tituloPersonalizado = "Crea tu propia salchi";
                    if (subCat === "Toppings Hamburguesa") tituloPersonalizado = "Personaliza tu burger";

                    const productosDeSub = productos.filter((p) => {
                        let subcategoria = extraerSubcategoria(p.categoria).toLowerCase();
                        let subCatNormalized = subCat.toLowerCase();

                        // Toppings especiales
                        if (p.categoria.toLowerCase().includes("topping") && subCatNormalized === "toppings salchipapa") {
                            return subcategoria === "salchipapas";
                        }
                        if (p.categoria.toLowerCase().includes("topping") && subCatNormalized === "toppings hamburguesa") {
                            return subcategoria === "hamburguesas";
                        }
                        if (subCatNormalized === "hamburguesas") {
                            return subcategoria === "hamburguesas" && !p.categoria.toLowerCase().includes("topping");
                        }

                        if (subcategoria.endsWith('a') && subCatNormalized.endsWith('as')) {
                            return subcategoria + 's' === subCatNormalized;
                        }

                        if (subCatNormalized.includes("perro")) {
                            return subcategoria === "perros" || subcategoria === "perro";
                        }

                        return subcategoria === subCatNormalized;
                    });


                    if (productosDeSub.length === 0) return null;

                    const backgroundColor = visibleIndex % 2 === 0 ? "#fff" : "#FFEAB5";
                    visibleIndex++;

                    return (
                        <Grid
                            container
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{ xs: 12, sm: 12, md: 12 }}
                            sx={{ backgroundColor }}
                            key={subCat}
                        >
                            <Grid
                                container
                                justifyContent="center"
                                size={{ xs: 12, sm: 12, md: 12 }}
                                sx={{ pt: 1, width: "100%" }}
                            >
                                <Grid container justifyContent={'center'} alignItems={'center'} size={{ xs: 12, sm: 12, md: 10 }} sx={{ my: 6, maxWidth: '1400px', px: 3 }} spacing={0}>
                                    <Typography
                                        sx={{
                                            fontSize: sCell ? 32 : 48,
                                            fontWeight: 600,
                                            px: 1,
                                            textAlign: 'center',
                                            pb:5
                                        }}
                                        id={subCat.toLowerCase().replace(/\s+/g, "-").replace(/[?¿]/g, "")}
                                    >
                                        {tituloPersonalizado}
                                    </Typography>

                                    <Grid container justifyContent="center" size={{ xs: 12, sm: 12, md: 12 }} spacing={0}>
                                        {productosDeSub.map((item) => (
                                            <Grid
                                                container sx={{pb:4}}
                                                size={
                                                    subCat === "Toppings Salchipapa" || subCat === "Toppings Hamburguesa"
                                                        ? { xs: 12, sm: 6, md: 3 }
                                                        : subCat === "Bebidas"
                                                            ? { xs: 12, sm: 12, md: 12 }
                                                            : { xs: 12, sm: 12, md: 6 }
                                                }
                                                key={item.id}
                                            >
                                                <Grid container size={{ xs: 12, sm: 12, md: 12 }} sx={{ py: 0 }}>
                                                    {subCat === "Para todo el parche" ? (
                                                        <Tarjeta_salchipapa_parche
                                                            titulo={item.titulo}
                                                            contenido={item.descripcion}
                                                            precio1={item.precio1}
                                                            precio2={item.precio2}
                                                            imagen={item.imagen}
                                                        />
                                                    ) : subCat === "Toppings Salchipapa" || subCat === "Toppings Hamburguesa" ? (
                                                        <Tarjeta_Toppings
                                                            titulo={item.titulo}
                                                            contenido={item.descripcion}
                                                            precio1={item.precio1}
                                                            imagen={item.imagen}
                                                        />
                                                    ) : subCat === "Bebidas" ? (
                                                        <Tarjeta_Bebidas
                                                            titulo={item.titulo}
                                                            precio1={item.precio1}
                                                        />
                                                    ) : (
                                                        <Tarjeta_menu
                                                            titulo={item.titulo}
                                                            contenido={item.descripcion}
                                                            precio1={item.precio1}
                                                            precio2={item.precio2}
                                                            imagen={item.imagen}
                                                        />
                                                    )}
                                                </Grid>
                                                <Grid
                                                    container
                                                    justifyContent="center"
                                                    alignItems="center"
                                                    size={{ xs: 12, sm: 12, md: 12 }}
                                                    sx={{ borderBottom: "1px solid black", pt:4 }}
                                                />
                                            </Grid>
                                        ))}
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    );
                });
            })()}
        </Grid>
    );
};

export default ListaMenu;

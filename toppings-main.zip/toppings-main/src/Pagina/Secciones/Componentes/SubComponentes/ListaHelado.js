import React, { useEffect, useState } from "react";
import { Grid, CircularProgress, Typography } from "@mui/material";
import Tarjeta_menu from "../../Tarjetas/Tarjeta_menu";
import Tarjeta_helados from "../../Tarjetas/Tarjeta_helados";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../../../../firebase/firebase";
import {useResponsive} from "../../../../Modulo_Responsive/Hooks/useResponsive";

const categoriasHelados = [
    "Conos soft",
    "Malteadas",
    "Malteadas (Sabores)",
    "Sundae tornado",
    "Sundae tornado (Toppings)",
    "Fruty soft",
    "Fruty soft (Base)",
    "Fruty soft (Toppings)",
    "Fruty soft (Frutas)",
    "Fruty soft (Salsas)",
    "Obleas",
    "Durazno con crema",
    "Durazno con crema (Toppings)",
    "Jugos naturales",
    "Jugos naturales (Frutas)",
];

// 🔹 Solo estas categorías tendrán scroll automático
const categoriasScroll = [
    "Conos soft",
    "Malteadas",
    "Sundae tornado",
    "Fruty soft",
    "Durazno con crema",
    "Jugos naturales",
    "Obleas"
];

const ListaHelado = () => {
    const { sCell } = useResponsive();
    const [productos, setProductos] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchProductos = async () => {
            try {
                const querySnapshot = await getDocs(collection(db, "helados"));
                const data = querySnapshot.docs.map((doc) => ({
                    id: doc.id,
                    ...doc.data(),
                }));
                setProductos(data);
            } catch (error) {
                console.error("❌ Error cargando productos:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchProductos();
    }, []);

    if (loading) {
        return (
            <Grid container justifyContent="center" alignItems="center" sx={{ minHeight: "200px" }}>
                <CircularProgress />
            </Grid>
        );
    }

    return (
        <Grid container justifyContent="center" alignItems="center" size={{ xs: 12, sm: 12, md: 12 }}>
            {(() => {
                let visibleIndex = 0; // 👈 Contador para intercalar solo en categorías visibles

                return categoriasHelados.map((subCat) => {
                    const productosDeSub = productos.filter(
                        (p) => p.categoria.trim() === subCat
                    );

                    if (productosDeSub.length === 0) return null;

                    // 🔹 Alternar fondo con visibleIndex en vez de index
                    const backgroundColor = visibleIndex % 2 === 0 ? "#fff" : "#FFEAB5";
                    visibleIndex++;

                    // 🔹 Normalizar título
                    let tituloSeccion = subCat;
                    if (subCat.includes("(")) {
                        const match = subCat.match(/\(([^)]+)\)/);
                        if (match) tituloSeccion = match[1];
                    }

                    const idCategoria = categoriasScroll.includes(subCat)
                        ? subCat.toLowerCase().replace(/\s+/g, "-")
                        : null;

                    return (
                        <Grid
                            key={subCat}
                            id={idCategoria || undefined}
                            container
                            justifyContent="center"
                            alignItems="center"
                            size={{ xs: 12 }}
                            sx={{ backgroundColor, py: 8, pt: sCell ? 8 : 0  }}
                        >
                            <Grid container justifyContent="center" size={{ xs: 12, sm: 12, md: 10 }} sx={{maxWidth: '1400px', px: 3 }} spacing={3}>
                                <Grid container justifyContent="center" size={{ xs: 12 }} sx={{mt:5, pb:3 }}  >
                                    <Typography
                                        sx={{ mb: 0, fontWeight: "bold", textTransform: "uppercase", fontSize: sCell ? 32 : 48, }}
                                    >
                                        {tituloSeccion}
                                    </Typography>
                                </Grid>

                                {productosDeSub.map((item) => (
                                    <Grid
                                        container
                                        justifyContent="center"
                                        key={item.id}
                                        size={
                                            subCat.includes("(")
                                                ? { xs: 6, sm: 4, md: 3 }
                                                : { xs: 12, sm: 6, md: 6 }
                                        }
                                    >
                                        {subCat.includes("(") ? (
                                            <Tarjeta_helados titulo={item.titulo} imagen={item.imagen} />
                                        ) : (
                                            <Tarjeta_menu
                                                titulo={item.titulo}
                                                contenido={item.descripcion}
                                                precio1={item.precio1}
                                                precio2={item.precio2}
                                                imagen={item.imagen}
                                            />
                                        )}
                                    </Grid>
                                ))}
                            </Grid>
                        </Grid>
                    );
                });
            })()}
        </Grid>
    );
};

export default ListaHelado;

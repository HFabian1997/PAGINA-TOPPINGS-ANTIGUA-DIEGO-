import {Grid, Typography} from "@mui/material";
import {useResponsive} from "../../../../Modulo_Responsive/Hooks/useResponsive";
import Tarjeta_Mas_Pedidos from "../../Tarjetas/Tarjeta_Mas_Pedidos";
import pedidos1 from "../../../../Recursos/pedidos.png";

const Lista_Mas_Pedidos = () => {
    const { sCell } = useResponsive();
    const pedidos = [
        {
            imagenes: pedidos1,
            nombre: 'La detodito',
            contenido: 'Papa criolla + queso +  salchicha ranchera y sencilla + chorizo + maduro + trosos de pollo + chicharrón + costilla ahumada + yuca + limon',
            precio1: 'Parche $ 65.5k',
            precio2: 'Parche $ 35.5k',
        },
        {
            imagenes: pedidos1,
            nombre: 'La detodito',
            contenido: 'Papa criolla + queso +  salchicha ranchera y sencilla + chorizo + maduro + trosos de pollo + chicharrón + costilla ahumada + yuca + limon',
            precio1: 'Parche $ 65.5k',
            precio2: 'Parche $ 35.5k',
        },
        {
            imagenes: pedidos1,
            nombre: 'La detodito',
            contenido: 'Papa criolla + queso +  salchicha ranchera y sencilla + chorizo + maduro + trosos de pollo + chicharrón + costilla ahumada + yuca + limon',
            precio1: 'Parche $ 65.5k',
            precio2: 'Parche $ 35.5k',
        },
    ];
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>
            <Grid
                container
                justifyContent="center"
                alignItems="center"
                spacing={3}
                size={{ xs: 12, sm: 12, md: 12 }}
                sx={{ pt: sCell ? 5 : 8 }}
            >
                {pedidos.map((pedidos, index) => (
                    <Grid
                        key={index}
                        container
                        alignItems="center"
                        justifyContent="center"
                        size={{ xs: 12, sm: 4, md: 4 }}
                    >
                        <Tarjeta_Mas_Pedidos
                            imagenes={pedidos.imagenes}
                            nombre={pedidos.nombre}
                            contenido={pedidos.contenido}
                            precio1={pedidos.precio1}
                            precio2={pedidos.precio2}
                        />
                    </Grid>
                ))}
            </Grid>
        </Grid>
    )
}
export default Lista_Mas_Pedidos;


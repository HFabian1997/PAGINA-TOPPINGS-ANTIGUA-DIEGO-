import { Button, Grid, Typography } from "@mui/material";

const Boton_Crear_Comidas = () => {
    return (
        <Grid
            container
            justifyContent={'flex-start'}
            alignItems={'center'}
            size={{ xs: 12, sm: 12, md: 12 }}
            sx={{
                position: 'fixed',
                top: '100px',
                backgroundColor: 'white',
                borderBottom: '2px solid #ccc',
                zIndex: 1000
            }}
        >
            <Grid
                container
                size={{ xs: 12, sm: 10, md: 10 }}
                sx={{ pb: 2,pt:2 }}
            >
                <Grid
                    container
                    size={{ xs: 12, sm: 12, md: 10 }}
                    sx={{ maxWidth: '1400px', px: 3 }}
                >
                    <Grid
                        container
                        size={{ xs: 12, sm: 12, md: 12 }}
                    >
                        <Grid container alignItems={'center'} size={{ xs: 12, sm: 6, md: 6 }}>
                            <Typography>
                                Helados
                            </Typography>
                        </Grid>

                        <Grid
                            container
                            justifyContent={'flex-end'}
                            alignItems={'center'}
                            size={{ xs: 12, sm: 6, md: 6 }}
                        >
                            <Button href={'/dashboard/helados/crear'}>
                                Crear
                            </Button>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    )
}

export default Boton_Crear_Comidas;

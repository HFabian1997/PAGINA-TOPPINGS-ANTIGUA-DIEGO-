import { Drawer, List, ListItem, ListItemText, ListItemIcon, Grid } from '@mui/material';
import { Link, useLocation } from 'react-router-dom';
import LunchDiningRoundedIcon from '@mui/icons-material/LunchDiningRounded';
import IcecreamRoundedIcon from '@mui/icons-material/IcecreamRounded';

const Slidebar_Dashboard = () => {

    const location = useLocation();

    const menuItems = [
        { text: 'Comidas', icon: <LunchDiningRoundedIcon />, path: '/dashboard/comidas' },
        { text: 'Helados', icon: <IcecreamRoundedIcon />, path: '/dashboard/helados' },
    ];

    return (
        <Grid
            container
            justifyContent={'flex-start'}
            alignItems={'flex-start'}
            sx={{backgroundColor:'#223B59', }} >

            <Drawer variant="permanent"
                    sx={{width: 240}} >
                <List sx={{ width: 240, pt:15}}>
                    {menuItems.map((item) => (
                        <ListItem
                            button
                            key={item.text}
                            component={Link}
                            to={item.path}
                            selected={location.pathname === item.path}
                        >
                            <ListItemIcon>{item.icon}</ListItemIcon>
                            <ListItemText primary={item.text} />
                        </ListItem>
                    ))}
                </List>
            </Drawer>

        </Grid>
    )

}
export default Slidebar_Dashboard;
import {Grid} from "@mui/material";
import Lista_Comidas_Dashboard from "./Lista_Comidas_Dashboard";
import Boton_Crear_Comidas from "./SubComponentes/Boton_Crear_Comidas";
import Boton_Crear_Helados from "./SubComponentes/Boton_Crear_Helados";
import Lista_Helados_Dashboard from "./Lista_Helados_Dashboard";

const Crear_Helados = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Boton_Crear_Helados/>
            </Grid>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Lista_Helados_Dashboard/>
            </Grid>
        </Grid>
    )
}
export default Crear_Helados;


import {Grid, Typography} from "@mui/material";
import Lista_Mas_Pedidos from "./SubComponentes/Lista_Mas_Pedidos";

const Lo_Mas_Pedido = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>
            <Grid
                container
                justifyContent={'center'}
                alignItems={'center'}
                size={{xs: 12, sm: 12, md: 10}}
                sx={{maxWidth: '1400px', px:3, pt:15}}>
                <Grid
                    container
                    justifyContent={'center'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Typography sx={{
                        fontSize: 48,
                        fontWeight: 600,
                        px: 1,
                        textAlign: 'center'
                    }}>
                        Los más pedidos
                    </Typography>
                </Grid>
                <Grid
                    justifyContent={'center'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Lista_Mas_Pedidos/>
                </Grid>
            </Grid>
        </Grid>
    )
}
export default Lo_Mas_Pedido;


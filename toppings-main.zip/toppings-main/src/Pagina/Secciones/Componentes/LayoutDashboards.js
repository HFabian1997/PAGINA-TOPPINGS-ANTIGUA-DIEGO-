import {Grid, CssBaseline, Box} from "@mui/material";
import {Outlet} from "react-router-dom";
import Slidebar_Dashboard from "./Slidebar_Dashboard";
import Topbar_Dashboard from "./Topbar_Dashboard";

const LayoutDashboard = () => {
    return (
        <Grid container
              justifyContent={'center'}
              alignItems={'flex-start'}
              size={{xs: 12, sm: 12, md: 12}}
              sx={{zIndex: 0, pt:15}}
        >
            <Grid container
                  justifyContent={'flex-start'}
                  alignItems={'flex-start'}
                  size={{xs: 12, sm: 12, md: 12}}>
                <Slidebar_Dashboard/>
            </Grid>
            <Grid container
                  justifyContent={'center'}
                  alignItems={'flex-start'}
                  size={{xs: 12, sm: 12, md: 12}}
            sx={{ml:'240px'}}>
                <Outlet/>
            </Grid>

        </Grid>
    );
};

export default LayoutDashboard;
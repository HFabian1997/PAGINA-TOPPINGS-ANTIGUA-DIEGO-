import React, { useEffect, useState } from "react";
import { CircularProgress, Grid } from "@mui/material";

const RouteLoadingWrapper = ({ children }) => {
    const [isLoading, setIsLoading] = useState(true);
    const [fadeOut, setFadeOut] = useState(false);

    useEffect(() => {
        const handleLoad = () => {
            setFadeOut(true);
            setTimeout(() => setIsLoading(false), 500);
        };

        if (document.readyState === 'complete') {
            handleLoad();
        } else {
            window.addEventListener('load', handleLoad);
            return () => window.removeEventListener('load', handleLoad);
        }
    }, []);

    return (
        <Grid
            sx={{
                position: 'relative',
                width: '100%',
                height: '100%',
                overflow: 'hidden',
            }}
        >
            {isLoading && (
                <Grid
                    sx={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: '100vw',
                        height: '100vh',
                        backgroundColor: '#fff',
                        zIndex: 2000,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: fadeOut ? 0 : 1,
                        transition: 'opacity 0.5s ease-in-out',
                        pointerEvents: 'none'
                    }}
                >
                    <CircularProgress size={60} thickness={4} sx={{ color: '#3E6AE1' }} />
                </Grid>
            )}

            <Grid
                sx={{
                    opacity: fadeOut ? 1 : 0,
                    transition: 'opacity 0.5s ease-in-out',
                }}
            >
                {children}
            </Grid>
        </Grid>
    );
};

export default RouteLoadingWrapper;

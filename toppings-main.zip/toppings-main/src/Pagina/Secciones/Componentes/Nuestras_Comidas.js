import { Grid, Typography } from "@mui/material";

const Nuestras_Comidas = () => {
    return (
        <Grid
            container
            justifyContent={"center"}
            alignItems={"center"}
            size={{ xs: 12, sm: 12, md: 12 }}
        >
            <Grid
                container
                justifyContent={"center"}
                alignItems={"center"}
                size={{ xs: 12, sm: 12, md: 10 }}
                sx={{ maxWidth: "1400px", px: 3, pt: 15 }}
            >
                <Grid
                    container
                    justifyContent={"center"}
                    alignItems={"center"}
                    size={{ xs: 12, sm: 12, md: 12 }}
                >
                    {/* Texto izquierda */}
                    <Grid
                        container
                        justifyContent={"flex-start"}
                        alignItems={"center"}
                        size={{ xs: 12, sm: 12, md: 6 }}
                    >
                        <Typography
                            sx={{
                                fontSize: 48,
                                fontWeight: 600,
                                textAlign: "left",
                                color: "black",
                                maxWidth: "450px",
                            }}
                        >
                            Nuestras comidas también rapean
                        </Typography>
                        <Typography
                            sx={{
                                fontSize: 16,
                                fontWeight: 300,
                                textAlign: "left",
                                color: "black",
                                pt: 2,
                                maxWidth: "450px",
                            }}
                        >
                            Mira la batalla de rap entre la papa y el helado, ¿quién crees
                            que ganó esta batalla de rap?
                        </Typography>
                    </Grid>

                    {/* Video derecha */}
                    <Grid
                        container
                        justifyContent={"center"}
                        alignItems={"center"}
                        size={{ xs: 12, sm: 12, md: 6 }}
                        sx={{ pt: 4 }}
                    >
                        <iframe
                            width="100%"
                            height="315"
                            src="https://www.youtube.com/embed/dQw4w9WgXcQ" // 👉 Cambia este link por el de tu video
                            title="YouTube video player"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            style={{ borderRadius: "12px", maxWidth: "560px" }}
                        ></iframe>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    );
};

export default Nuestras_Comidas;

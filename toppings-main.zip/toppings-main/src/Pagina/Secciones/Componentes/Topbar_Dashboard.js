// src/components/Topbar.js
import { AppBar, Toolbar, Typography, IconButton, Grid} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';

const Topbar_Dashboard = () => {

    return (
        <Grid
            container
            justifyContent={'flex-start'}
            alignItems={'flex-start'}
            size={{xs: 12, sm: 12, md: 12}} sx={{pt:10}}>
            <AppBar position="static" color="default" elevation={1}>
                <Toolbar>
                    <IconButton edge="start" color="inherit" aria-label="menu" sx={{ mr: 2 }}>
                        <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" noWrap component="div">
                        Admin Panel
                    </Typography>
                </Toolbar>
            </AppBar>

        </Grid>
    )

}
export default Topbar_Dashboard;
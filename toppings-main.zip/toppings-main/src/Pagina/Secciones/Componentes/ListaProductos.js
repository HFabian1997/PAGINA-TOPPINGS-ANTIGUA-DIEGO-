import { useEffect, useState } from "react";
import { db } from "../../../firebase/firebase";
import { collection, getDocs } from "firebase/firestore";
import { Grid, Typography, Card, CardContent, CardMedia } from "@mui/material";

const ListaProductos = () => {
    const [productos, setProductos] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            const querySnap = await getDocs(collection(db, "productos"));
            const lista = querySnap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
            setProductos(lista);
        };
        fetchData();
    }, []);

    return (
        <Grid container spacing={3} sx={{ p: 3 }}>
            {productos.map((prod) => (
                <Grid item xs={12} sm={6} md={4} key={prod.id}>
                    <Card>
                        {prod.imagenes?.[0] && (
                            <CardMedia
                                component="img"
                                height="200"
                                image={prod.imagenes[0]}
                                alt={prod.nombre}
                            />
                        )}
                        <CardContent>
                            <Typography variant="h6">{prod.nombre}</Typography>
                            <Typography variant="body2" color="text.secondary">
                                {prod.descripcion}
                            </Typography>
                            <Typography variant="subtitle1">Precio 1: ${prod.precio1}</Typography>
                            <Typography variant="subtitle1">Precio 2: ${prod.precio2}</Typography>
                        </CardContent>
                    </Card>
                </Grid>
            ))}
        </Grid>
    );
};

export default ListaProductos;

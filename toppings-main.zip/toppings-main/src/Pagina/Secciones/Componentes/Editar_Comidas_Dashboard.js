import {
    Grid,
    TextField,
    MenuItem,
    Button,
    CircularProgress,
    Typography,
    Snackbar,
    Alert
} from "@mui/material";
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { db, storage } from "../../../firebase/firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

const Editar_Comida_Dashboard = () => {
    const { id } = useParams();

    const [categoria, setCategoria] = useState('');
    const [titulo, setTitulo] = useState('');
    const [descripcion, setDescripcion] = useState('');
    const [precio1, setPrecio1] = useState('');
    const [precio2, setPrecio2] = useState('');
    const [imagen, setImagen] = useState(null);
    const [existingImageUrl, setExistingImageUrl] = useState('');
    const [loading, setLoading] = useState(false);
    const [snackbarOpen, setSnackbarOpen] = useState(false);

    const secciones = {
        Salchipapas: ['Una salchi o miedo?', 'Somos las salchis más chimbas', 'Para todo el parche'],
        Hamburguesas: ['Hamburguesas'],
        Perros: ['Te gustan perro o perras?'],
        Sándwich: ['Sandwiches para una persona', 'Sandwiches para dos personas'],
        Mazorcada: ['Mazorcadas'],
        Otros: ['Otros'],
        Bebidas: ['Bebidas'],
        Topping: ['Salchipapas', 'Hamburguesas']
    };

    const categoriasConFormato = Object.entries(secciones).flatMap(([cat, subs]) =>
        subs.length > 1 ? subs.map((sub) => `${cat} (${sub})`) : [cat]
    );

    useEffect(() => {
        const fetchComida = async () => {
            try {
                const docRef = doc(db, "productos", id);
                const docSnap = await getDoc(docRef);
                if (docSnap.exists()) {
                    const data = docSnap.data();
                    setCategoria(data.categoria || '');
                    setTitulo(data.titulo || '');
                    setDescripcion(data.descripcion || '');
                    setPrecio1(data.precio1 || '');
                    setPrecio2(data.precio2 || '');
                    setExistingImageUrl(data.imagen || '');
                }
            } catch (error) {
                console.error("Error al cargar la comida:", error);
            }
        };

        fetchComida();
    }, [id]);

    const handleImageChange = (e) => {
        if (e.target.files[0]) {
            setImagen(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // 🔹 Validaciones dinámicas
        if (categoria.includes("Bebidas")) {
            if (!titulo.trim() || !precio1.trim()) {
                alert('Los campos de bebida son obligatorios.');
                return;
            }
        } else if (categoria.includes("Topping")) {
            if (!descripcion.trim() || !precio1.trim()) {
                alert('Los campos de topping son obligatorios.');
                return;
            }
        } else {
            if (!categoria || !titulo.trim() || !descripcion.trim() || !precio1.trim()) {
                alert('Todos los campos son obligatorios.');
                return;
            }
        }

        setLoading(true);
        try {
            let imageUrl = existingImageUrl;

            if (imagen) {
                const folder = categoria.split(" ")[0].toLowerCase().replace(/ /g, '_');
                const imageRef = ref(storage, `${folder}/${Date.now()}_${imagen.name}`);
                await uploadBytes(imageRef, imagen);
                imageUrl = await getDownloadURL(imageRef);
            }

            await updateDoc(doc(db, "productos", id), {
                categoria,
                titulo,
                descripcion,
                precio1,
                precio2,
                imagen: imageUrl
            });

            setSnackbarOpen(true);
        } catch (error) {
            console.error("Error al actualizar la comida:", error);
            alert('Error al actualizar la comida');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Grid container justifyContent="flex-start" alignItems="flex-start">
            <Grid
                container justifyContent="flex-start" alignItems="flex-start"
                component="form"
                onSubmit={handleSubmit}
                sx={{ maxWidth: 500, px: 3, pt: 5 }}
            >
                {/* Categoría */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }} sx={{ mb: 2 }}>
                    <TextField
                        select
                        label="Categoría"
                        fullWidth
                        value={categoria}
                        onChange={(e) => setCategoria(e.target.value)}
                    >
                        {categoriasConFormato.map((cat) => (
                            <MenuItem key={cat} value={cat}>
                                {cat}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>

                {/* Formulario dinámico */}
                {categoria.includes("Bebidas") && (
                    <>
                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Nombre de la Bebida"
                                fullWidth
                                margin="normal"
                                value={titulo}
                                onChange={(e) => setTitulo(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Precio"
                                fullWidth
                                margin="normal"
                                value={precio1}
                                onChange={(e) => setPrecio1(e.target.value)}
                            />
                        </Grid>
                    </>
                )}

                {categoria.includes("Topping") && (
                    <>
                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Descripción"
                                fullWidth
                                multiline
                                rows={3}
                                margin="normal"
                                value={descripcion}
                                onChange={(e) => setDescripcion(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Precio"
                                fullWidth
                                margin="normal"
                                value={precio1}
                                onChange={(e) => setPrecio1(e.target.value)}
                            />
                        </Grid>
                    </>
                )}

                {!categoria.includes("Bebidas") && !categoria.includes("Topping") && (
                    <>
                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Nombre del Plato"
                                fullWidth
                                margin="normal"
                                value={titulo}
                                onChange={(e) => setTitulo(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Ingredientes"
                                fullWidth
                                multiline
                                rows={3}
                                margin="normal"
                                value={descripcion}
                                onChange={(e) => setDescripcion(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Valor 1"
                                fullWidth
                                margin="normal"
                                value={precio1}
                                onChange={(e) => setPrecio1(e.target.value)}
                            />
                        </Grid>

                        <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                            <TextField
                                label="Valor 2"
                                fullWidth
                                margin="normal"
                                value={precio2}
                                onChange={(e) => setPrecio2(e.target.value)}
                            />
                        </Grid>
                    </>
                )}

                {/* Imagen */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                    <Button component="label" variant="outlined" fullWidth sx={{ mt: 2 }}>
                        {existingImageUrl ? 'Cambiar Imagen' : 'Subir Imagen'}
                        <input type="file" hidden accept="image/*" onChange={handleImageChange} />
                    </Button>
                    {imagen && (
                        <Typography variant="body2" sx={{ mt: 1 }}>
                            {imagen.name}
                        </Typography>
                    )}
                    {!imagen && existingImageUrl && (
                        <Typography variant="body2" sx={{ mt: 1 }}>
                            Imagen actual: {existingImageUrl.split('/').pop()}
                        </Typography>
                    )}
                </Grid>

                {/* Botón */}
                <Grid container size={{ xs: 12, sm: 12, md: 12 }}>
                    <Button type="submit" variant="contained" fullWidth sx={{ mt: 3 }} disabled={loading}>
                        {loading ? <CircularProgress size={24} /> : 'Actualizar Producto'}
                    </Button>
                </Grid>
            </Grid>

            <Snackbar
                open={snackbarOpen}
                autoHideDuration={3000}
                onClose={() => setSnackbarOpen(false)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
            >
                <Alert onClose={() => setSnackbarOpen(false)} severity="success" sx={{ width: '100%' }}>
                    Producto actualizado correctamente
                </Alert>
            </Snackbar>
        </Grid>
    );
};

export default Editar_Comida_Dashboard;

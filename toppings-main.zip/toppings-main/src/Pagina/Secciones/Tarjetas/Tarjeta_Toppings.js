import {Grid, Link, Typography} from "@mui/material";
import {useResponsive} from "../../../Modulo_Responsive/Hooks/useResponsive";

const Tarjeta_Toppings = ({imagen, titulo, contenido, precio1,}) => {
    const {sCell} = useResponsive()
    return (
        <Grid
            container
            component="article"
            justifyContent={'flex-start'}
            alignItems={'flex-start'}
            size={{xs: 12, sm: 12, md: 12}}
            sx={{py:5}}>
            <Grid container
                  justifyContent={'flex-start'}
                  alignItems={'center'}
                  size={{xs: 12, sm: 12, md: 12}}>
                <Grid
                    container
                    justifyContent={'flex-start'}
                    alignItems={'center'}
                    size={{xs: 7, sm: 7, md: 7}}>
                    <Grid
                        container
                        justifyContent={'center'}
                        alignItems={'center'}
                        size={{xs: 12, sm: 12, md: 12}}>
                        <Grid
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 12,
                                    fontWeight: 300,
                                    color: '#223B59',
                                    pl:2,
                                }}
                            >
                                {titulo}
                            </Typography>
                        </Grid>
                        <Grid
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 12,
                                    fontWeight: 300,
                                    color: '#223B59',
                                    pl:2,
                                }}
                            >
                                {contenido}
                            </Typography>
                        </Grid>
                        <Grid
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 18,
                                    fontWeight: 500,
                                    color: '#223B59',
                                    pl:2,
                                }}
                            >
                                {precio1}
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid
                    container
                    justifyContent={'flex-end'}
                    alignItems={'center'}
                    size={{ xs: 5, sm: 5, md: 5 }}
                    // sx={{
                    //     width: {
                    //         xs: '40%',
                    //         sm: '150px',
                    //         md: '200px'
                    //     },
                    //     aspectRatio: '1 / 1',
                    //     overflow: 'hidden',
                    //     borderRadius: '8px',
                    // }}
                >
                    <img
                        src={imagen}
                        alt={contenido}
                        loading="lazy"
                        style={{
                            width: '100%',
                            height: '100%',
                            objectFit: 'cover',
                            display: 'block'
                        }}
                    />
                </Grid>
            </Grid>
        </Grid>
    )

}
export default Tarjeta_Toppings;
import { Grid, Typography } from "@mui/material";
import { useResponsive } from "../../../Modulo_Responsive/Hooks/useResponsive";

const Tarjeta_Toppings = ({ imagen, titulo }) => {
    const { sCell } = useResponsive();

    return (
        <Grid
            container
            component="article"
            justifyContent="center"
            alignItems="center"
            size={{ xs: 12, sm: 12, md: 12 }}

        >
            <Grid
                container
                justifyContent="flex-start"
                alignItems="center"
                sx={{
                    backgroundColor: "#CC6F0F",
                    borderRadius: "50px",
                    padding: "8px 16px",
                    display: "flex",
                    flexDirection: "row",
                    gap: "10px",
                    width: "200px",
                    height: "60px",
                    cursor: "pointer",
                }}
            >
                <img
                    src={imagen}
                    alt={titulo}

                    style={{
                        width: "40px",
                    }}
                />

                <Typography
                    sx={{
                        fontFamily: "Poppins",
                        fontSize: 16,
                        fontWeight: 500,
                        color: "#fff",
                    }}
                >
                    {titulo}
                </Typography>
            </Grid>
        </Grid>
    );
};

export default Tarjeta_Toppings;

import {Grid, Typography, Link} from "@mui/material";
import {useResponsive} from "../../../Modulo_Responsive/Hooks/useResponsive";

const Tarjeta_Proyectos = ({imagen, titulo, id}) => {
    const {sCell} = useResponsive()
    return (
        <Grid
            container
            justifyContent={'flex-start'}
            alignItems={'flex-start'}
            size={{xs: 12, sm: 12, md: 12}}>
            <Link href={`/proyectos/${id}`}  underline="none">

                <Grid container
                      justifyContent={'flex-start'}
                      alignItems={'center'} size={{xs: 12, sm: 12, md: 12}}>
                    <Grid
                        container
                        justifyContent={'flex-start'}
                        alignItems={'flex-start'}
                        size={{xs: 5, sm: 5, md: 5}}>
                        <img
                            src={imagen}
                            alt={titulo}
                            style={{
                                width: '100%',
                                height: 'auto',
                                borderRadius: '8px',
                                objectFit: 'cover'
                            }}
                        />
                    </Grid>
                    <Grid
                        container
                        justifyContent={'flex-start'}
                        alignItems={'flex-start'}
                        size={{xs: 7, sm: 7, md: 7}} sx={{pl:3}}>
                        <Grid container size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: sCell ? 16 : 24,
                                    fontWeight: 600,
                                    color: '#223B59',
                                    lineHeight: 1.4
                                }}
                            >
                                {titulo}
                            </Typography>
                        </Grid>

                        <Grid
                            container
                            justifyContent={'flex-start'}
                            alignItems={'flex-start'}
                            size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 10,
                                    fontWeight: 400,
                                    color: '#223B59',
                                }}
                            >
                                Cocina para apartamento
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>

            </Link>
        </Grid>
    )
}
export default Tarjeta_Proyectos;


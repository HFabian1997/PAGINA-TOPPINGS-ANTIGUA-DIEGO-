import {Grid, Link, Typography} from "@mui/material";
import {useResponsive} from "../../../Modulo_Responsive/Hooks/useResponsive";

const Tarjeta_menu = ({imagen, titulo, contenido, precio1, precio2}) => {
    const {sCell} = useResponsive()
    return (
        <Grid
            container
            component="article"
            justifyContent={'flex-start'}
            alignItems={'flex-start'}
            size={{xs: 12, sm: 12, md: 12}}
            sx={{py:0}} columnSpacing={0}>
                <Grid container
                      justifyContent={'flex-start'}
                      alignItems={'center'}
                      size={{xs: 12, sm: 12, md: 12}}>
                    <Grid
                        container
                        justifyContent={'flex-start'}
                        alignItems={'center'}
                        size={{xs: 7, sm: 7, md: 7}}
                        sx={{pr:2}}>
                        <Grid
                            container
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{xs: 12, sm: 12, md: 12}}
                        sx={{pl:2}}>
                            <Grid
                                justifyContent={'center'}
                                alignItems={'center'}
                                size={{xs: 12, sm: 12, md: 12}}>
                                <Typography
                                    component="h3"
                                    sx={{
                                        fontFamily: 'Poppins',
                                        fontSize:  18,
                                        fontWeight: 500,
                                        color: '#223B59',
                                    }}
                                >
                                    {titulo}
                                </Typography>
                            </Grid>
                            <Grid
                                justifyContent={'center'}
                                alignItems={'center'}
                                size={{xs: 12, sm: 12, md: 12}}>
                                <Typography
                                    component="h3"
                                    sx={{
                                        fontFamily: 'Poppins',
                                        fontSize: 12,
                                        fontWeight: 300,
                                        color: '#223B59',
                                    }}
                                >
                                    {contenido}
                                </Typography>
                            </Grid>
                            <Grid
                                justifyContent={'center'}
                                alignItems={'center'}
                                size={{xs: 12, sm: 12, md: 12}}>
                                <Typography
                                    component="h3"
                                    sx={{
                                        fontFamily: 'Poppins',
                                        fontSize: 18,
                                        fontWeight: 500,
                                        color: '#223B59',
                                    }}
                                >
                                    {precio1}
                                </Typography>
                            </Grid>
                            <Grid
                                justifyContent={'center'}
                                alignItems={'center'}
                                size={{xs: 12, sm: 12, md: 12}}>
                                <Typography
                                    component="h3"
                                    sx={{
                                        fontFamily: 'Poppins',
                                        fontSize: 18,
                                        fontWeight: 500,
                                        color: '#223B59',
                                    }}
                                >
                                    {precio2}
                                </Typography>
                            </Grid>
                        </Grid>
                    </Grid>
                    <Grid
                        container
                        justifyContent={'flex-end'}
                        alignItems={'center'}
                        size={{ xs: 5, sm: 5, md: 5 }}
                        sx={{
                            width: {
                                sm: '140px',
                                md: '165px'
                            },
                            aspectRatio: '1 / 1',
                            overflow: 'hidden',
                            borderRadius: '30px',
                        }}
                    >
                        <img
                            src={imagen}
                            alt={titulo}
                            loading="lazy"
                            style={{
                                width: '100%',
                                height: '100%',
                                objectFit: 'cover',
                                display: 'block'
                            }}
                        />
                    </Grid>
                </Grid>
        </Grid>
    )

}
export default Tarjeta_menu;
import {Grid, Link, Typography} from "@mui/material";
import {useResponsive} from "../../../Modulo_Responsive/Hooks/useResponsive";

const Tarjeta_Bebidas = ({imagen, titulo, precio1,}) => {
    const {sCell} = useResponsive()
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>
            <Grid container
                  justifyContent={'center'}
                  alignItems={'center'}
                  size={{xs: 12, sm: 12, md: 12}}>
                <Grid
                    container
                    justifyContent={'center'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Grid
                        container
                        size={{xs: 12, sm: 12, md: 12}}>
                        <Grid
                            justifyContent={'flex-start'}
                            alignItems={'center'}
                            size={{xs: 6, sm: 6, md: 6}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 18,
                                    fontWeight: 500,
                                    color: '#223B59',
                                    pl:0,
                                }}
                            >
                                {titulo}
                            </Typography>
                        </Grid>
                        <Grid
                            container
                            justifyContent={'flex-end'}
                            alignItems={'center'}
                            size={{xs: 6, sm: 6, md: 6}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 18,
                                    fontWeight: 500,
                                    color: '#223B59',
                                    pl:0,
                                }}
                            >
                                {precio1}
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    )

}
export default Tarjeta_Bebidas;
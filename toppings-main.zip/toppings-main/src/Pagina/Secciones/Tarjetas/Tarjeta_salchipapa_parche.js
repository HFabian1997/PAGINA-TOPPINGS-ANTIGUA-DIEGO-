import {Grid, Link, Typography} from "@mui/material";
import {useResponsive} from "../../../Modulo_Responsive/Hooks/useResponsive";

const Tarjeta_salchipapa_parche = ({imagen, titulo, contenido, precio1, precio2}) => {
    const {sCell} = useResponsive()
    return (
        <Grid
            container
            component="article"
            justifyContent={'flex-start'}
            alignItems={'flex-start'}
            size={{xs: 12, sm: 12, md: 12}} sx={{py:5, pr: sCell? 0:4}}>
            <Grid container
                  justifyContent={'flex-start'}
                  alignItems={'center'}
                  size={{xs: 12, sm: 12, md: 12}} gap={2}>
                <Grid
                    container
                    justifyContent={'flex-start'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Grid
                        container
                        justifyContent={'center'}
                        alignItems={'center'}
                        size={{xs: 12, sm: 12, md: 12}}>
                        <Grid
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize:  18,
                                    fontWeight: 500,
                                    color: '#223B59',
                                }}
                            >
                                {titulo}
                            </Typography>
                        </Grid>
                        <Grid
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 12,
                                    fontWeight: 300,
                                    color: '#223B59',
                                }}
                            >
                                {contenido}
                            </Typography>
                        </Grid>
                        <Grid
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 18,
                                    fontWeight: 500,
                                    color: '#223B59',
                                }}
                            >
                                {precio1}
                            </Typography>
                        </Grid>
                        <Grid
                            justifyContent={'center'}
                            alignItems={'center'}
                            size={{xs: 12, sm: 12, md: 12}}>
                            <Typography
                                component="h3"
                                sx={{
                                    fontFamily: 'Poppins',
                                    fontSize: 18,
                                    fontWeight: 500,
                                    color: '#223B59',
                                }}
                            >
                                {precio2}
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid
                    container
                    justifyContent={'flex-start'}
                    alignItems={'center'}
                    size={{ xs: 12, sm: 12, md: 12 }}
                    sx={{pt:0}}
                >
                    <img
                        src={imagen}
                        alt={titulo}
                        loading="lazy"
                        style={{
                            width: sCell? '100%':'90%',
                            objectFit: 'cover',
                            display: 'block'
                        }}
                    />
                </Grid>
            </Grid>
        </Grid>
    )

}
export default Tarjeta_salchipapa_parche;
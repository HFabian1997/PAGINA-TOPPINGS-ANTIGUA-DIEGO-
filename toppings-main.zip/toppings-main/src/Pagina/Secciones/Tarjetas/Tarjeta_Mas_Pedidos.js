import {ButtonBase, Grid, Typography} from "@mui/material";
import { useResponsive } from "../../../Modulo_Responsive/Hooks/useResponsive";
import { Link } from "react-router-dom";
import ChevronRightRoundedIcon from "@mui/icons-material/ChevronRightRounded";

const Tarjeta_Novedades_Seccion_Blogs = ({ imagenes, nombre, contenido, precio1, precio2  }) => {
    const { sCell } = useResponsive();

    return (
            <Grid
                container
                justifyContent="center"
                alignItems="center"
                size={{ xs: 12, sm: 12, md: 12 }}>
                <Grid
                    container
                    justifyContent={'center'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <img
                        src={imagenes}
                        alt={nombre}
                        style={{
                            width: '100%',
                            borderRadius: '12px',
                        }}
                    />
                </Grid>
                <Grid
                    container
                    justifyContent={'flex-start'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Typography sx={{fontSize: 18, fontWeight: 600, textAlign: 'center', pt:2}}>
                        {nombre}
                    </Typography>
                </Grid>
                <Grid
                    container
                    justifyContent={'flex-start'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Typography sx={{fontSize: 12, fontWeight: 300, textAlign: 'flex-start', pt:0}}>
                        {contenido}
                    </Typography>
                </Grid>
                <Grid
                    container
                    justifyContent={'flex-start'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Typography sx={{fontSize: 16, fontWeight: 600, textAlign: 'center'}}>
                        {precio1}
                    </Typography>
                </Grid>
                <Grid
                    container
                    justifyContent={'flex-start'}
                    alignItems={'center'}
                    size={{xs: 12, sm: 12, md: 12}}>
                    <Typography sx={{fontSize: 16, fontWeight: 600, textAlign: 'center'}}>
                        {precio2}
                    </Typography>
                </Grid>
            </Grid>
    );
};

export default Tarjeta_Novedades_Seccion_Blogs;

import {Grid,} from "@mui/material";
import ListaHelado from "./Componentes/SubComponentes/ListaHelado";


const Seccion_Helados = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}
            sx={{pt:25}}>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <ListaHelado />
            </Grid>

        </Grid>
    )
}
export default Seccion_Helados;


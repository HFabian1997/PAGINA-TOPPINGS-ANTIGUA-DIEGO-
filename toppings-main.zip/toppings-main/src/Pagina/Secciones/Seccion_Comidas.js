import {Grid,} from "@mui/material";
import Lo_Mas_Pedido from "./Componentes/Lo_Mas_Pedido";
import ListaMenu from "./Componentes/SubComponentes/ListaMenu";


const Seccion_Comidas = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <ListaMenu />
            </Grid>
        </Grid>
    )
}
export default Seccion_Comidas;


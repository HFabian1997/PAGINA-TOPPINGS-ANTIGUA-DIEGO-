import {Grid, Typography} from "@mui/material";
import Lo_Mas_Pedido from "./Componentes/Lo_Mas_Pedido";
import Cono_Gratis from "./Componentes/Cono_Gratis";
import Pagina_Misteriosa from "./Componentes/Pagina_Misteriosa";
import Nuestras_Comidas from "./Componentes/Nuestras_Comidas";
import Opiniones from "./Componentes/Opiniones";
import ListaProductos from "./Componentes/ListaProductos";

const Seccion_Actividades = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Lo_Mas_Pedido />
            </Grid>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Cono_Gratis/>
            </Grid>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Pagina_Misteriosa/>
            </Grid>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Nuestras_Comidas/>
            </Grid>
            <Grid container size={{xs: 12, sm: 12, md: 12}}>
                <Opiniones/>
            </Grid>
        </Grid>
    )
}
export default Seccion_Actividades;


import {Grid} from "@mui/material";
import BarraPc from "./BarraPc";
import BarraCell from "./BarraCell";
import {useResponsive} from "../../Modulo_Responsive/Hooks/useResponsive";

const Barra = () => {
    const {masSM} = useResponsive()

    return (
        <Grid
            container
            justifyContent={'flex-start'}
            alignItems={'flex-start'}
            size={{xs: 12, sm: 12, md: 12}}
        >
            {masSM ?
                <BarraPc/>
                :
                <BarraCell/>
            }
        </Grid>
    )

}
export default Barra
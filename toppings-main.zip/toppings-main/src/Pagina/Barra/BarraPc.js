import React, { useState, useRef, useEffect } from "react";
import { Grid, Typography, ButtonBase } from "@mui/material";
import { Link, useLocation } from "react-router-dom";
import logo from "../../Recursos/logo.svg";
import IcecreamRoundedIcon from '@mui/icons-material/IcecreamRounded';
import LunchDiningRoundedIcon from '@mui/icons-material/LunchDiningRounded';

const BarraPc = () => {
    const [pos, setPos] = useState({ left: 0, width: 0 });
    const location = useLocation();

    const comidasRef = useRef(null);
    const heladosRef = useRef(null);
    const contenedorRef = useRef(null);
    const headerRef = useRef(null);

    const seleccion =
        location.pathname === "/comidas" || location.pathname === "/"
            ? "comidas"
            : location.pathname === "/helados"
                ? "helados"
                : "comidas";

    useEffect(() => {
        let ref = null;
        if (seleccion === "comidas") ref = comidasRef.current;
        else if (seleccion === "helados") ref = heladosRef.current;

        if (ref && contenedorRef.current) {
            const rect = ref.getBoundingClientRect();
            const contRect = contenedorRef.current.getBoundingClientRect();
            setPos({ left: rect.left - contRect.left, width: rect.width });
        }
    }, [seleccion]);

    const categoriasComidas = [
        "Salchipapas",
        "Hamburguesa",
        "Perros",
        "Sandwich",
        "Mazorcada",
        "Otros",
        "Bebidas",
    ];

    const categoriasHelados = [
        "Conos soft",
        "Malteadas",
        "Sundae tornado",
        "Fruty soft",
        "Obleas",
        "Durazno con crema",
        "Jugos naturales",

    ];

    const mapScroll = {
        "Salchipapas": "una-salchi-o-miedo",
        "Hamburguesa": "hamburguesas",
        "Perros": "te-gustan-perro-o-perras",
        "Sandwich": "sandwiches-para-una-persona",
        "Mazorcada": "mazorcadas",
        "Otros": "otros",
        "Bebidas": "bebidas",

        // helados
        "Conos soft": "conos-soft",
        "Malteadas": "malteadas",
        "Sundae tornado": "sundae-tornado",
        "Fruty soft": "fruty-soft",
        "Obleas": "obleas",
        "Durazno con crema": "durazno-con-crema",
        "Ensalada de frutas": "ensalada-de-frutas",
        "Jugos naturales": "jugos-naturales",

    };

    const scrollToWithOffset = (targetId) => {
        if (!targetId) return;
        const element = document.getElementById(targetId);
        if (!element) return;

        const headerHeight = headerRef.current
            ? headerRef.current.getBoundingClientRect().height
            : 0;

        const y = element.getBoundingClientRect().top + window.scrollY - headerHeight - 8;
        window.scrollTo({ top: y, behavior: "smooth" });
    };

    return (
        <Grid
            ref={headerRef}
            container
            justifyContent="center"
            alignItems="center"
            size={{ xs: 12, sm: 12, md: 12 }}
            sx={{
                position: 'fixed',
                width: '100%',
                backgroundColor: 'white',
                top: 0,
                zIndex: 1300,
                pt: 2,
                pb: 1,
                borderBottom: '1px solid #4C4A4A',
            }}
        >
            <Grid
                container
                justifyContent="center"
                alignItems="center"
                size={{ xs: 12, sm: 12, md: 12 }}
                sx={{ maxWidth: "1400px", px: 3, pt: 0, gap: 2 }}
            >
                <Grid container justifyContent="center">
                    <Link to="/actividades">
                        <img
                            src={logo}
                            alt="Toppings Logo"
                            style={{ width: 80, height: 80, borderRadius: "50%", cursor: "pointer" }}
                        />
                    </Link>
                </Grid>

                <Grid
                    ref={contenedorRef}
                    container
                    justifyContent="center"
                    alignItems="center"
                    sx={{
                        position: "relative",
                        maxWidth: "600px",
                        borderRadius: "50px",
                        overflow: "hidden",
                        backgroundColor: "#FFA602",
                        px: 0,
                        py: 0,
                        gap: 6,
                    }}
                >
                    {seleccion && (
                        <div
                            style={{
                                position: "absolute",
                                top: 5.5,
                                left: pos.left + 8,
                                width: pos.width - 16,
                                height: "calc(100% - 11px)",
                                backgroundColor: "#C16D00",
                                borderRadius: "50px",
                                transition: "all 0.5s cubic-bezier(0.77, 0, 0.175, 1)",
                                zIndex: 0,
                            }}
                        />
                    )}

                    <Grid
                        ref={comidasRef}
                        item
                        xs
                        component={Link}
                        to="/comidas"
                        sx={{
                            color: "white",
                            textAlign: "center",
                            py: 1,
                            px: 4,
                            cursor: "pointer",
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            justifyContent: "center",
                            position: "relative",
                            zIndex: 1,
                            textDecoration: "none",
                        }}
                    >
                        <LunchDiningRoundedIcon fontSize="large" />
                        <Typography sx={{ fontSize: 16, fontWeight: 100 }}>
                            Comidas
                        </Typography>
                    </Grid>

                    <Grid
                        ref={heladosRef}
                        item
                        xs
                        component={Link}
                        to="/helados"
                        sx={{
                            color: "white",
                            textAlign: "center",
                            py: 1,
                            px: 4,
                            cursor: "pointer",
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            justifyContent: "center",
                            position: "relative",
                            zIndex: 1,
                            textDecoration: "none",
                        }}
                    >
                        <IcecreamRoundedIcon fontSize="large" />
                        <Typography sx={{ fontSize: 16, fontWeight: 100 }}>
                            Helados
                        </Typography>
                    </Grid>
                </Grid>
            </Grid>

            {/* Botones comidas */}
            {seleccion === "comidas" && (
                <Grid
                    container
                    justifyContent="center"
                    alignItems="center"
                    size={{ xs: 12, sm: 12, md: 12 }}
                    sx={{ mt: 1, gap: 2 }}
                >
                    {categoriasComidas.map((cat, index) => (
                        <ButtonBase
                            key={index}
                            onClick={() => scrollToWithOffset(mapScroll[cat])}
                            sx={{
                                borderRadius: "20px",
                                textTransform: "none",
                                fontWeight: 500,
                                fontSize: "14px",
                                padding: "2px 12px",
                                backgroundColor: "#f5f5f5",
                                color: "black",
                                boxShadow: "none",
                                "&:hover": { backgroundColor: "#e0e0e0" },
                            }}
                        >
                            {cat}
                        </ButtonBase>
                    ))}
                </Grid>
            )}

            {/* Botones helados */}
            {seleccion === "helados" && (
                <Grid
                    container
                    justifyContent="center"
                    alignItems="center"
                    size={{ xs: 12, sm: 12, md: 12 }}
                    sx={{ mt: 2, gap: 2 }}
                >
                    {categoriasHelados.map((cat, index) => (
                        <ButtonBase
                            key={index}
                            onClick={() => scrollToWithOffset(mapScroll[cat])}
                            sx={{
                                borderRadius: "20px",
                                textTransform: "none",
                                fontWeight: 500,
                                fontSize: "14px",
                                padding: "2px 12px",
                                backgroundColor: "#f5f5f5",
                                color: "black",
                                boxShadow: "none",
                                "&:hover": { backgroundColor: "#e0e0e0" },
                            }}
                        >
                            {cat}
                        </ButtonBase>
                    ))}
                </Grid>
            )}
        </Grid>
    );
};

export default BarraPc;

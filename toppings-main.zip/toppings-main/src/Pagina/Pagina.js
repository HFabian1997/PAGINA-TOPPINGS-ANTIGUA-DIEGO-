import { Grid } from "@mui/material";
import Footer from "./Footer";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Seccion_Actividades from "./Secciones/Seccion_Actividades";
import Barra from "./Barra/Barra";
import Seccion_Comidas from "./Secciones/Seccion_Comidas";
import Seccion_Helados from "./Secciones/Seccion_Helados";
import LayoutDashboard from "./Secciones/Componentes/LayoutDashboards";
import Crear_Comidas from "./Secciones/Componentes/Crear_Comidas";
import Crear_Comidas_Dashboard from "./Secciones/Componentes/Crear_Comidas_Dashboard";
import Editar_Comidas_Dashboard from "./Secciones/Componentes/Editar_Comidas_Dashboard";
import {Navigate} from 'react-router-dom';
import Crear_Helados from "./Secciones/Componentes/Crear_Helados";
import Crear_Helados_Dashboard from "./Secciones/Componentes/Crear_Helados_Dashboard";
import Editar_Helados_Dashboard from "./Secciones/Componentes/Editar_Helados_Dashboard";

const Pagina = () => {
    return (
        <Grid
            container
            justifyContent={'center'}
            alignItems={'center'}
            size={{xs: 12, sm: 12, md: 12}}>

            <Router>
                {/* Barra de navegación */}
                <Grid container size={{xs: 12, sm: 12, md: 12}}>
                    <Barra/>
                </Grid>

                {/* Rutas */}
                <Routes>
                    <Route path="*" element={<Seccion_Comidas/>} />
                    <Route path="/" element={<Seccion_Comidas/>} />
                    <Route path="/actividades" element={<Seccion_Actividades />} />
                    <Route path="/comidas" element={<Seccion_Comidas />} />
                    <Route path="/helados" element={<Seccion_Helados />} />



                    <Route path="/dashboard" element={<LayoutDashboard/>}>
                        <Route index element={<Navigate to="comidas" replace />} />

                        <Route path="comidas" element={<Crear_Comidas />} />
                        <Route path="menu/crear" element={<Crear_Comidas_Dashboard />} />
                        <Route path="menu/:id" element={<Editar_Comidas_Dashboard />} />

                        <Route path="helados" element={<Crear_Helados/>} />
                        <Route path="helados/crear" element={<Crear_Helados_Dashboard/>} />
                        <Route path="helados/:id" element={<Editar_Helados_Dashboard/>} />
                    </Route>

                </Routes>

                {/* Footer */}
                <Grid container size={{xs: 12, sm: 12, md: 12}}>
                    <Footer/>
                </Grid>
            </Router>
        </Grid>
    )
}
export default Pagina;

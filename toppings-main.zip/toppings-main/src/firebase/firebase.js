import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
    apiKey: "AIzaSyC4a77tDDjxg1e8swirktOKjiTREWYXSeU",
    authDomain: "toppings-colon.firebaseapp.com",
    projectId: "toppings-colon",
    storageBucket: "toppings-colon.firebasestorage.app",
    messagingSenderId: "602883009080",
    appId: "1:602883009080:web:7cb89333a7dcd5003fd4cd",
    measurementId: "G-T5V5FPEM68"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);


export { db, storage};

// PrivateRoute.js
import { Navigate } from "react-router-dom";
import { useAuthState } from "react-firebase-hooks/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "./firebase";
import { useState, useEffect } from "react";

export function PrivateRoute({ children, allowedRoles }) {
    const [user, loading] = useAuthState(auth);
    const [role, setRole] = useState(null);
    const [checkingRole, setCheckingRole] = useState(true);

    useEffect(() => {
        const fetchRole = async () => {
            if (user) {
                const ref = doc(db, "users", user.uid);
                const snap = await getDoc(ref);
                if (snap.exists()) {
                    setRole(snap.data().role);
                }
            }
            setCheckingRole(false);
        };
        if (user) fetchRole();
    }, [user]);

    if (loading || checkingRole) return <p>Cargando...</p>;

    if (!user) return <Navigate to="/login" />;
    if (role && !allowedRoles.includes(role)) return <Navigate to="/login" />;

    return children;
}
